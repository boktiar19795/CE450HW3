def adder(f1, f2):
    def add_func(x):
        return f1(x) + f2(x)
    
    return add_func


def identity(n):
    return n


def square(n):
    return n ** 2


def ask_exit():
    while True:
        choice = input("Do you want to exit? (yes/no): ").lower()
        if choice == "yes":
            return True
        elif choice == "no":
            return False
        else:
            print("Invalid choice. Please enter 'yes' or 'no'.")


def run_code():
    a1 = adder(identity, square)
    while True:
        try:
            x = float(input("Enter a value for x: "))
            result = a1(x)
            print("Result:", result)
        except ValueError:
            print("Invalid input. Please enter a numeric value.")

        if ask_exit():
            print("Exiting the code...")
            break


# Run the code
run_code()
