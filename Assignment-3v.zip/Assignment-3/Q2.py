def fancy_prnt():
    def replace():
        try:
            n= int(input("Enter the buzz number:" ))
            limit = int(input("Enter the limit: "))
            if limit <= 0:
                print("The range from 0 to", limit, "does not generate any numbers.")
            else:
                for i in range(limit):
                    if i % n == 0:
                        print("Buzz!")
                    else:
                        print(i)
        except ValueError:
            print("Invalid Input")
    
    return replace


def ask_exit():
    while True:
        choice = input("Do you want to exit? (yes/no): ").lower()
        if choice == "yes":
            return True
        elif choice == "no":
            return False
        else:
            print("Invalid choice. Please enter 'yes' or 'no'.")


def run_code():
    replace = fancy_prnt()
    while True:
        replace()
        if ask_exit():
            print("Exiting the code...")
            break


# Run the code
run_code()