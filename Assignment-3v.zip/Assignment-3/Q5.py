def intscts(f, x):
    def g(func):
        return f(x) == func(x)
    return g


def square(n):
    return n ** 2


def triple(n):
    return 3 * n


def increment(n):
    return n + 1


def identity(n):
    return n


while True:
    try:
        f_name = input("Enter the name of the function (square, triple, increment, identity): ")
        x = int(input("Enter the value for x: "))

        if f_name == "square":
            f = square
        elif f_name == "triple":
            f = triple
        elif f_name == "increment":
            f = increment
        elif f_name == "identity":
            f = identity
        else:
            print("Invalid function name. Please try again.")
            continue

        g_name = input("Enter the name of the function to check against (square, triple, increment, identity): ")

        if g_name == "square":
            g = square
        elif g_name == "triple":
            g = triple
        elif g_name == "increment":
            g = increment
        elif g_name == "identity":
            g = identity
        else:
            print("Invalid function name. Please try again.")
            continue

        at_x = intscts(f, x)
        print(at_x(g))

        choice = input("Do you want to exit? (y/n): ")
        if choice.lower() == "y":
            break

    except ValueError:
        print("Invalid input. Please enter a valid integer for x.")

print("Exiting the code...")
