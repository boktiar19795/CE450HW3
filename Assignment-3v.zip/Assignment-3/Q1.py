def abndnt(n):
    if n == 1:
        return False

    divisors = []
    for i in range(1, int(n ** 0.5) + 1):
        if n % i == 0:
            divisors.append(i)
            if i != n // i:
                divisors.append(n // i)

    divisors.sort()

    for i in range(len(divisors) - 1):
        for j in range(i, len(divisors)):
            if divisors[i] * divisors[j] == n:
                print(f"{divisors[i]} * {divisors[j]}")

    return sum(divisors) > 2 * n


# Keep running the code until the user chooses to exit
while True:
    try:
        # Accept input from the user
        num = int(input("Enter a positive integer: "))

        if num <= 0:
            print("Invalid input! Please enter a positive integer.")
            continue

        # Call the function and print the result
        result = abndnt(num)
        print(result)

        # Ask the user if they want to continue or exit
        choice = input("Do you want to continue? (y/n): ")
        if choice.lower() != 'y':
            print("Exiting the code...")
            break

    except ValueError:
        print("Invalid input! Please enter a positive integer.")

